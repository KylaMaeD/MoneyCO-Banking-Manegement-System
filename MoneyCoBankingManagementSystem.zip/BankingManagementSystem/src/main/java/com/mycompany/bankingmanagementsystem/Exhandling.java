/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankingmanagementsystem;

import javax.swing.JOptionPane;

/**
 *
 * @author JOHN RAMON
 */
public class Exhandling {
    public static boolean integerCheck(String... tests) {
         for (String test : tests) {
            try {
                Integer.parseInt(test);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "The input should be a number: " + test, "Warning", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }
        return true;
    }

    public static boolean moneyCheck(String... tests) {
         for (String test : tests) {
            try {
                Double.parseDouble(test);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "The input should be a number: " + test, "Warning", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }
        return true;
    }
	
    public static boolean emptyFieldsCheck(Object...params) {
		for (Object param :params){
			if (param.equals("")) {
				JOptionPane.showMessageDialog(null, "Please fill in all fields", "Warning", JOptionPane.WARNING_MESSAGE);
				return false;
			}
		}
        return true;
	}
		
    public static boolean emptyMoneyFieldsCheck(String test ){
        double money = Double.parseDouble(test);
        if (money == 0){
            JOptionPane.showMessageDialog(null, "The amount should not be equal to zero", "Warning", JOptionPane.WARNING_MESSAGE);
            return false;
        }
    return true;
    }


    public static boolean lengthchecker(String test, int length, String name) {
        if (test.length() != length) {
            JOptionPane.showMessageDialog(null, "The " + name + " should be " + length + " characters long.", "Warning", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
    
    public static boolean limitsCheck(String test, String limit) {
        try {
            double money = Double.parseDouble(test);
            
            // Try parsing the limit as an integer
            try {
                double mlimits = Double.parseDouble(limit);
                
                // Check if money is within the valid range
                if (money >= 0 && money <= mlimits) {
                    return true;
                } else if (money < 0) {
                    JOptionPane.showMessageDialog(null, "The amount should not go below 0", "Reminders", JOptionPane.ERROR_MESSAGE);
                    return false;
                } else {
                    JOptionPane.showMessageDialog(null, "The amount should not exceed " + limit, "Reminders", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "The limit should be a valid number", "Reminders", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "The input should be a number", "Reminders", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static boolean commaCheck(Object...params) {
	for (Object param :params){
	        String str = param.toString(); // Convert param to String
	        boolean test = str.contains(",");
		if (test) {
			JOptionPane.showMessageDialog(null, "Please don't input commas in the input field, thank you", "Reminder", JOptionPane.WARNING_MESSAGE);
			return false;
			}
		}
        return true;
	}
    
    
}
