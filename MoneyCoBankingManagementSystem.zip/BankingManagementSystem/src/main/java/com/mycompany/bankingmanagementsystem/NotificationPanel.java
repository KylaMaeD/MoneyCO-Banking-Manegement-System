/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.bankingmanagementsystem;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class NotificationPanel extends javax.swing.JPanel {

    // Declare necessary variables for creating a notification panel
    String transactionTime;
    String transactionType;
    String accountNumber;
    String sourceOrRecipient;
    String initialBalance;
    String updatedBalance;
    String transactionReceipt;
    String transactionAmount;
    String accountType;
    
    // declare pointer to account holder panel
    AccountHolderPanel pointerToAccountHolderPanel;
    
    // declare pointer to clerk panel
    ClerkPanel pointerToClerkPanel;
    
    public NotificationPanel(String number,
            String type,
            String time,
            String amount,
            String account,
            String oldBalance,
            String newBalance,
            String receipt,
            String accType) {
        
        initComponents();
        
        // Initialize the necessary variables
        accountNumber = number;
        transactionType = type;
        transactionTime = time;
        transactionAmount = amount;
        sourceOrRecipient = account;
        initialBalance = oldBalance;
        updatedBalance = newBalance;
        transactionReceipt = receipt;
        accountType = accType;
        
        // Initialize the pointer to account holder panel
        pointerToAccountHolderPanel = null;
        
        // Initialize the pointer to clerk panel
        pointerToClerkPanel = null;
        
        
        // display the received details into their labels
        transactionTimeAndTypeLbl.setText(String.format("%s - %s", transactionTime, transactionType));

        // display the receipt number
        receiptLbl.setText(String.format("Receipt No. %s", transactionReceipt));
        
        // display balances
        initialBalanceLbl.setText(String.format("₱%s", initialBalance));
        updatedBalanceLbl.setText(String.format("₱%s", updatedBalance));
        
        if (accountType.equals("Shareholder")) {
            // displays different message for shareholder
            switch (transactionType) {
                case "Deposit" -> // display a prompt specific to deposit transaction
                    amountTransferredLblAndSourceOrRecipientLbl.setText(String.format("You have deposited ₱%s to your bank account.",
                            transactionAmount));
                case "Withdrawal" -> // display a prompt specific to withdrawal transaction
                    amountTransferredLblAndSourceOrRecipientLbl.setText(String.format("You have withdrawn ₱%s from your bank account.",
                            transactionAmount));
                default -> {
                }
            }

            // display specific prompt for bank transfer
            if (transactionType.equals("Transfer") && Double.valueOf(initialBalance) > Double.valueOf(updatedBalance)) {
                amountTransferredLblAndSourceOrRecipientLbl.setText(String.format("You have transferred ₱%s from your bank account to account number: %s.",
                            transactionAmount, sourceOrRecipient));
            }
            else if (transactionType.equals("Transfer") && Double.valueOf(initialBalance) < Double.valueOf(updatedBalance)) {
                amountTransferredLblAndSourceOrRecipientLbl.setText(String.format("Account number %s have transferred ₱%s to your bank account.",
                            sourceOrRecipient, transactionAmount));
            }
            
        }
        else if (accountType.equals("Clerk")) {
            // display different message for clerks
            switch (transactionType) {
                case "Deposit" -> // display a prompt specific to deposit transaction
                    amountTransferredLblAndSourceOrRecipientLbl.setText(String.format("Account %s have deposited ₱%s to their bank account.",
                            accountNumber,
                            transactionAmount));
                case "Withdrawal" -> // display a prompt specific to withdrawal transaction
                    amountTransferredLblAndSourceOrRecipientLbl.setText(String.format("Account %s have withdrawn ₱%s from their bank account.",
                            accountNumber,
                            transactionAmount));
                case "Transfer" -> // display a prompt specific to transfer transaction
                    amountTransferredLblAndSourceOrRecipientLbl.setText(String.format("Account %s have transferred ₱%s from their bank account to Account %s.",
                            accountNumber,
                            transactionAmount,
                            sourceOrRecipient));
                default -> {
                }
            }
        }
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        transactionTimeAndTypeLbl = new javax.swing.JLabel();
        amountTransferredLblAndSourceOrRecipientLbl = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        updatedBalanceLbl = new javax.swing.JLabel();
        initialBalanceLbl = new javax.swing.JLabel();
        markAsReadLblBtn = new javax.swing.JLabel();
        receiptLbl = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(934, 207));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        transactionTimeAndTypeLbl.setText(" Time - Transaction Type");
        jPanel1.add(transactionTimeAndTypeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 26, -1, -1));

        amountTransferredLblAndSourceOrRecipientLbl.setText("999 has been transferred to your account from 325");
        jPanel1.add(amountTransferredLblAndSourceOrRecipientLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 85, -1, -1));

        jLabel6.setText("Initial Balance:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 118, -1, -1));

        jLabel7.setText("Updated Balance:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 140, -1, -1));

        updatedBalanceLbl.setText("jLabel8");
        jPanel1.add(updatedBalanceLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 140, -1, -1));

        initialBalanceLbl.setText("jLabel13");
        jPanel1.add(initialBalanceLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 118, -1, -1));

        markAsReadLblBtn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        markAsReadLblBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/MarkAsRead.png"))); // NOI18N
        markAsReadLblBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        markAsReadLblBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                markAsReadLblBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                markAsReadLblBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                markAsReadLblBtnMousePressed(evt);
            }
        });
        jPanel1.add(markAsReadLblBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 133, 179, 60));

        receiptLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        receiptLbl.setText("Receipt No: 2024070001");
        jPanel1.add(receiptLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(747, 26, 210, -1));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 1000, 200));
    }// </editor-fold>//GEN-END:initComponents

    // Sets the pointer to clerk panel
    public void setPointerToAccountHolder(AccountHolderPanel accountHolderPanel) {
        pointerToAccountHolderPanel = accountHolderPanel;
    }
    
    // Sets the pointer to clerk panel
    public void setPointerToClerk(ClerkPanel clerkPanel) {
        pointerToClerkPanel = clerkPanel;
    }
    
    private void markAsReadLblBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_markAsReadLblBtnMousePressed
        
        // mark the notification as read
        if (accountType.equals("Shareholder")) {
            try {
                // Read the contents of the log and transfer them to a temporary file
                BufferedReader reader = new BufferedReader(new FileReader("TransactionLog.csv"));
                PrintWriter writer = new PrintWriter(new FileWriter("TemporaryFile.csv"));
                String line;

                // loop through each line in the file
                while ((line = reader.readLine()) != null) {
                    String[] accountDetails = line.split(",");

                    writer.append(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                        accountDetails[0],
                        accountDetails[1],
                        accountDetails[2],
                        accountDetails[3],
                        accountDetails[4],
                        accountDetails[5],
                        accountDetails[6],
                        accountDetails[7],
                        accountDetails[8]));
                    }
                    reader.close();
                    writer.close();

                    // Read the contents of the temporary file and transfer them to the transaction log
                    reader = new BufferedReader(new FileReader("TemporaryFile.csv"));
                    writer = new PrintWriter(new FileWriter("TransactionLog.csv"));

                    // loop through each line in the file
                    while ((line = reader.readLine()) != null) {
                        String[] accountDetails = line.split(",");

                        // Search for the record
                        if (!(transactionReceipt.equals(accountDetails[7]))) {
                            writer.append(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                                accountDetails[0],
                                accountDetails[1],
                                accountDetails[2],
                                accountDetails[3],
                                accountDetails[4],
                                accountDetails[5],
                                accountDetails[6],
                                accountDetails[7],
                                accountDetails[8]));
                    }
                    else {
                        // mark the record as read
                        writer.append(String.format("%s,%s,%s,%s,%s,%s,%s,%s,Read\n",
                            accountDetails[0],
                                accountDetails[1],
                                accountDetails[2],
                                accountDetails[3],
                                accountDetails[4],
                                accountDetails[5],
                                accountDetails[6],
                                accountDetails[7]));
                        }
                    }
                    writer.close();
                
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(ClerkPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(ClerkPanel.class.getName()).log(Level.SEVERE, null, ex);
                }

            // refresh the notification panel
            pointerToAccountHolderPanel.displayNotifications();
            pointerToAccountHolderPanel.refreshNotificationsPanel();
        }
        else if (accountType.equals("Clerk")) {
            
            try {
                // Read the contents of the log and transfer them to a temporary file
                BufferedReader reader = new BufferedReader(new FileReader("BankReserveLog.csv"));
                PrintWriter writer = new PrintWriter(new FileWriter("TemporaryFile.csv"));
                String line;

                // loop through each line in the file
                while ((line = reader.readLine()) != null) {
                    String[] accountDetails = line.split(",");

                    writer.append(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                        accountDetails[0],
                        accountDetails[1],
                        accountDetails[2],
                        accountDetails[3],
                        accountDetails[4],
                        accountDetails[5],
                        accountDetails[6],
                        accountDetails[7],
                        accountDetails[8]));
                    }
                    reader.close();
                    writer.close();

                    // Read the contents of the temporary file and transfer them to the transaction log
                    reader = new BufferedReader(new FileReader("TemporaryFile.csv"));
                    writer = new PrintWriter(new FileWriter("BankReserveLog.csv"));

                    // loop through each line in the file
                    while ((line = reader.readLine()) != null) {
                        String[] accountDetails = line.split(",");

                        // Search for the record
                        if (!(transactionReceipt.equals(accountDetails[7]))) {
                            writer.append(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                                accountDetails[0],
                                accountDetails[1],
                                accountDetails[2],
                                accountDetails[3],
                                accountDetails[4],
                                accountDetails[5],
                                accountDetails[6],
                                accountDetails[7],
                                accountDetails[8]));
                    }
                    else {
                        // mark the record as read
                        writer.append(String.format("%s,%s,%s,%s,%s,%s,%s,%s,Read\n",
                            accountDetails[0],
                                accountDetails[1],
                                accountDetails[2],
                                accountDetails[3],
                                accountDetails[4],
                                accountDetails[5],
                                accountDetails[6],
                                accountDetails[7]));
                        }
                    }
                    writer.close();

                } catch (FileNotFoundException ex) {
                    Logger.getLogger(ClerkPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(ClerkPanel.class.getName()).log(Level.SEVERE, null, ex);
                }

            // refresh the notification panel
            pointerToClerkPanel.displayNotifications();
            pointerToClerkPanel.refreshNotificationsPanel();
        }
        
    }//GEN-LAST:event_markAsReadLblBtnMousePressed

    private void markAsReadLblBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_markAsReadLblBtnMouseExited
        // TODO add your handling code here:
           markAsReadLblBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/MarkAsRead.png"))); // NOI18N
    }//GEN-LAST:event_markAsReadLblBtnMouseExited

    private void markAsReadLblBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_markAsReadLblBtnMouseEntered
        // TODO add your handling code here:
            markAsReadLblBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/MarkAsRead_enter.png"))); // NOI18N
    }//GEN-LAST:event_markAsReadLblBtnMouseEntered


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel amountTransferredLblAndSourceOrRecipientLbl;
    private javax.swing.JLabel initialBalanceLbl;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel markAsReadLblBtn;
    private javax.swing.JLabel receiptLbl;
    private javax.swing.JLabel transactionTimeAndTypeLbl;
    private javax.swing.JLabel updatedBalanceLbl;
    // End of variables declaration//GEN-END:variables
}
