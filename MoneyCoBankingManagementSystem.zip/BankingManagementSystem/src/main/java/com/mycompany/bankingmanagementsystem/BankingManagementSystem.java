/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bankingmanagementsystem;

/**
 *
 * Main method
 */
public class BankingManagementSystem {

    public static void main(String[] args) {
        
        // Open the Main JFrame to begin the program.
        new MainFrame().setVisible(true);
        
        // Simple indicator that the code compiled properly.
        System.out.println("Hello World!");
    }
}
